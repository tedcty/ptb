class classproperty(object):
     def __init__(self, getter):
         self.getter= getter
     def __get__(self, instance, owner):
         return self.getter(owner)


class Config:

    @classproperty
    def version(self):
        return "0.1.17"


    @classproperty
    def info(self):
        print("PTB Version = {0}".format(Config.version))
        ret = {
            'version': "{0}".format(Config.version)
        }
        return ret