@property
def version():
    return "0.1.13"


@property
def info():
    print("PTB Version = {0}".format(version()))
    ret = {
        'version': "{0}".format(version())
    }
    return ret

