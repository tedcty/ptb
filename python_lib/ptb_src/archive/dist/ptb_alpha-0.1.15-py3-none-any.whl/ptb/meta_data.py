
class Config:

    @property
    def version(self):
        return "0.1.15"


    @property
    def info(self):
        print("PTB Version = {0}".format(Config.version))
        ret = {
            'version': "{0}".format(Config.version)
        }
        return ret