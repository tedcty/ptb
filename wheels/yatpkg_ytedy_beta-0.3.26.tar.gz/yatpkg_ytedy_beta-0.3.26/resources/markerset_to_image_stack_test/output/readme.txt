tiff stack
