from yatpkg.util.data import VTKMeshUtl


if __name__ == '__main__':
    root = "E:/VRS_reconstruct/VIFM-ShapeModel-HumerusScapula/"
    mean_mesh = VTKMeshUtl.load(root+"00_0000_HumerusScapula_Both_mean.stl.ply")
    aa = VTKMeshUtl.load(root + "AA.ply")
    aa_points = VTKMeshUtl.extract_points(aa)
    point_set = VTKMeshUtl.closest_point_set(aa_points, mean_mesh)
    pass