from yatpkg.util.data import StorageIO, Yac3do


if __name__ == '__main__':
    x = "X:/SFTIWearable/Test/S17/Session/heel rise.c3d"
    a = StorageIO.simple_readc3d(x)
    b = StorageIO.readc3d_general(x)
    c = Yac3do(x)
    markers = c.markers
    trc = c.trc
    pass
