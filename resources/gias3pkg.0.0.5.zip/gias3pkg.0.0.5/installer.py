import os
from enum import Enum


class Parameter(Enum):
    opensim = 'opensim'
    wheels = 'wheels'
    unknown = -1

    @staticmethod
    def find(p_name):
        for p in Parameter:
            if p.value == p_name:
                return p
        return Parameter.unknown


def read_config(filename):
    config = {}
    with open(filename) as f:
        lines = f.readlines()
    for line in lines:
        if '=' in line:
            info = line.split("=")
            config[Parameter.find(info[0])] = info[1].strip()
    return config


if __name__ == '__main__':
    """
    This script install gias3 components in order
    Requirements:
        Opensim 4.3
        Python 3.8
    """
    print("This helper script installs gias3 components in the order of dependence using wheels.")
    configs = read_config("./install_config.cfg")
    location_of_wheels = configs[Parameter.wheels]
    opensim = configs[Parameter.opensim]
    # gias module install order
    module_list = [
        "gias3.common",
        "gias3.fieldwork",
        "gias3.registration",
        "gias3.learning",
        "gias3.image_analysis",
        "gias3.mesh",
        "gias3",
        "gias3.musculoskeletal",
        "gias3.mapclientpluginutilities",
        "gias3.visualisation",
        "gias3.applications",
        "gias3.examples"
    ]

    print("\nInstalling Critical Dependencies: ")
    # This install critical dependencies used by mayavi
    dependencies = ['numpy', 'scipy', 'PyQt5', 'vtk']
    for d in dependencies:
        os.system('python -m pip install ' + d)

    print("\nInstalling General Dependencies: ")
    dependencies = ['Pillow', 'tables', 'pandas', 'matplotlib', 'pymeshlab']
    for d in dependencies:
        os.system('python -m pip install ' + d)

    print("\nInstalling dependency: mayavi")
    os.system('python -m pip install mayavi')

    print('\nInstalling dependency: opensim 4.3 sdk')
    # This installation method used by opensim will generate a Deprecation Warning
    # You might see this message:
    # ------------------------------------------------------------------------------------------------------------------
    # DEPRECATION: A future pip version will change local packages to be built in-place without first copying to a
    # temporary directory. We recommend you use --use-feature=in-tree-build to test your packages with this new behavior
    # before it becomes the default.
    #
    # pip 21.3 will remove support for this functionality. You can find discussion regarding this at
    # https://github.com/pypa/pip/issues/7555.
    # ------------------------------------------------------------------------------------------------------------------
    script_dir = os.getcwd()
    os.chdir(opensim+'sdk/Python/')
    os.system('python ./setup_win_python38.py')
    os.system('python -m pip install .')

    os.chdir(script_dir)
    print("\nGias3 modules being installed are (in order): ")
    for p in range(0, len(module_list)):
        print('\t{0}. {1}'.format(p + 1, module_list[p]))
    print('\n')
    wheels = [f for f in os.listdir(location_of_wheels) if f.endswith('.whl')]
    for m in module_list:
        current_wheel = [f for f in wheels if m in f]
        print("\nInstalling " + current_wheel[0])
        os.system('python -m pip install ' + location_of_wheels + current_wheel[0])
        print("Done.\n")

    print()
