import os
import sys
import subprocess
import threading


import importlib.util
spam_spec = importlib.util.find_spec("PyQt5")
found = spam_spec is not None
if not found:
    print("PyQt5 Not Available Installing PyQt5")
    os.system('python -m pip install PyQt5')
    print("Done .... Please Rerun Script to continue!")
    sys.exit(0)
else:
    print("PyQt5 Available Launching GUI")
try:
    from PyQt5.QtWidgets import QMainWindow, QApplication, QWidget, QHBoxLayout, QVBoxLayout, QLineEdit, QProgressBar, QTextEdit
    from PyQt5.QtWidgets import QPushButton, QSlider, QLabel, QCheckBox, QToolTip, QAction, QStatusBar, QFileDialog, QSizePolicy
    from PyQt5.Qt import Qt, QSize
    from PyQt5.QtGui import QIcon, QFont, QPalette, QColor, QTextCursor
except ModuleNotFoundError:
    pass

conda_boo = False

information = "<html>Welcome to the Gias3 Installer.<br>This app will help you install Gias3 into your environment."
information += "<br>--------------------------------------------------------------------"
information += "<b>Requirements</b>:"
information += "<br><br><b>1)</b> Installer requires your to run inside an Anaconda or Miniconda environment."
information += "<br><br><b>2)</b> If you are using the Muscloskeletal module you will need to install Opensim first."
information += "<br><a href=\"https://simtk.org/frs/?group_id=91\">https://simtk.org/frs/?group_id=91</a>"
information += "<br>--------------------------------------------------------------------"
information += "<br><b>Log:</b><br>"


def run_general_install():
    """
       This script install gias3 components in order
       Requirements:
           Opensim 4.3
           Python 3.10
       """
    print("This helper script installs gias3 components in the order of dependence using wheels.")
    # gias module install order
    module_list = [
        "gias3",
        "gias3.musculoskeletal",
        "gias3.mapclientpluginutilities",
        "gias3.visualisation",
        "gias3.applications",
        "gias3.examples",
        "gias3.io"
    ]

    print("\nInstalling General Dependencies: ")
    # This install critical dependencies used by mayavi
    dependencies = ['numpy', 'scipy', 'vtk', 'Pillow', 'tables', 'pandas', 'matplotlib', 'pymeshlab']
    for d in dependencies:
        os.system('python -m pip install ' + d)

    print("\nInstalling dependency: mayavi")
    os.system('python -m pip install mayavi')

    print("\nInstalling dependency: Opensim")
    os.system('conda install -c opensim-org opensim')

    print("\nGias3 modules being installed are (in order): ")
    for p in range(0, len(module_list)):
        print('\t{0}. {1}'.format(p + 1, module_list[p]))
    print('\n')

    for m in module_list:
        print("\nInstalling " + m)
        os.system('python -m pip install ' + m)
        print("Done.\n")

    print()


class InfoWidget(QWidget):
    def __init__(self, root):
        super().__init__()
        try:
            print(sys.path)
            user_paths = [f for f in sys.path if "Python" in f]
            user_paths = user_paths[0].split("\\")
            user_path = ""
            for i in range(0, len(user_paths)):
                if user_paths[i] != "Python":
                    user_path += user_paths[i] + "\\"
                else:
                    break
            user_path += user_paths[i+1]
            user_paths = [user_path]

        except KeyError:
            user_paths = ["Unknown"]
        self.root = root
        self.left_side = QVBoxLayout()
        self.python_loc = LTBWidget(self, "Python", "Open", user_paths[0])
        self.textEdit = QTextEdit()
        self.textEdit.setText(information)
        self.pbar = QProgressBar(self)
        self.pbar.setValue(0)
        self.pbar.setAlignment(Qt.AlignCenter)
        self.pbar.setTextVisible(False)
        self.left_side.addWidget(self.python_loc)
        self.left_side.addWidget(self.textEdit)
        self.left_side.addWidget(self.pbar)
        self.setLayout(self.left_side)


class LTBWidget(QWidget):
    def __init__(self, root, nlabel_l="", nbutton_l="", input_e=""):
        global conda_boo, information
        super().__init__()
        self.root = root
        self.nlabel = QLabel(nlabel_l)
        self.input_text = QLineEdit(input_e)
        self.nbutton = QPushButton(nbutton_l)
        self.nbutton.clicked.connect(self.do_something)
        self.h_layout = QHBoxLayout()
        self.h_layout.addWidget(self.nlabel)
        self.h_layout.addWidget(self.input_text)
        self.h_layout.addWidget(self.nbutton)
        self.setLayout(self.h_layout)
        if not conda_boo:
            information += "<br>> Searching for conda in python path ..."
            if os.path.exists(self.input_text.text()+"\\Scripts\\"):
                information += "Found!<br>> Activating Conda ..."
                os.system(self.input_text.text()+"\\Scripts\\activate.bat")
                information += "Done!"

    def do_something(self):
        print("something")


class VisualControlWidget(QWidget):

    def __init__(self, root):
        super().__init__()
        self.root = root
        QToolTip.setFont(QFont('Arial', 12))
        title = QLabel('Components:')
        space = QLabel(' ')
        space2 = QLabel(' ')
        space3 = QLabel(' ')
        space4 = QLabel(' ')
        core_label = QLabel('Core:')

        self.gias3_label = QCheckBox('Gias3')
        self.gias3_label.setChecked(True)
        self.gias3_label.setToolTip('Check for installing Gias3 Core components')

        addon_label = QLabel('Addons:')

        self.musculoskeletal_label = QCheckBox('Musculoskeletal')
        self.musculoskeletal_label.setChecked(True)
        self.musculoskeletal_label.setToolTip('Check for installing Musculoskeletal Module\nThis requires the installing of Opensim.\nChecking will install Opensim python sdk to your environment.')

        self.mapclientpluginutilities_label = QCheckBox('Mapclientpluginutilities')
        self.mapclientpluginutilities_label.setChecked(True)
        self.mapclientpluginutilities_label.setToolTip('The MAP Client plugin utility packages of the GIAS3 libraries')

        self.visualisation_label = QCheckBox('Visualisation')
        self.visualisation_label.setChecked(True)

        self.applications_label = QCheckBox('Applications')
        self.applications_label.setChecked(True)

        self.examples_label = QCheckBox('Examples')
        self.examples_label.setChecked(True)

        self.io_label = QCheckBox('io')
        self.io_label.setChecked(True)

        visual = QLabel('Visual Elements:')
        self.mayavi_label = QCheckBox('Mayavi')
        self.mayavi_label.setChecked(True)

        visualr = QLabel('Third Party:')
        self.opensim_label = QCheckBox('Opensim Python SDK')
        self.opensim_label.setChecked(True)

        self.map_list = {
            "mayavi:": [self.mayavi_label, 'python -m pip install mayavi'],
            "gias3": [self.gias3_label, 'python -m pip install gias3'],
            "opensim": [self.opensim_label, 'conda install -c -y opensim-org opensim'],
            "gias3.musculoskeletal": [self.musculoskeletal_label, 'python -m pip install gias3.musculoskeletal'],
            "gias3.mapclientpluginutilities": [self.mapclientpluginutilities_label, 'python -m pip install gias3.mapclientpluginutilities'],
            "gias3.visualisation": [self.visualisation_label, 'python -m pip install gias3.visualisation'],
            "gias3.applications": [self.applications_label, 'python -m pip install gias3.applications'],
            "gias3.examples": [self.examples_label, 'python -m pip install gias3.examples'],
            "gias3.io": [self.io_label, 'python -m pip install gias3.io']
        }

        self.left_side = QVBoxLayout()
        self.left_side.addWidget(title)
        self.left_side.addWidget(space)
        self.left_side.addWidget(core_label)
        self.left_side.addWidget(self.gias3_label)
        self.left_side.addWidget(space2)
        self.left_side.addWidget(addon_label)
        self.left_side.addWidget(self.musculoskeletal_label)
        self.left_side.addWidget(self.mapclientpluginutilities_label)
        self.left_side.addWidget(self.visualisation_label)
        self.left_side.addWidget(self.applications_label)
        self.left_side.addWidget(self.examples_label)
        self.left_side.addWidget(self.io_label)
        self.left_side.addWidget(space3)
        self.left_side.addWidget(visual)
        self.left_side.addWidget(self.mayavi_label)
        self.left_side.addWidget(space4)
        self.left_side.addWidget(visualr)
        self.left_side.addWidget(self.opensim_label)
        self.left_side.addStretch(5)
        self.left_side.setSpacing(2)
        self.left_side.addWidget(QLabel(' '))
        self.reset_button = QPushButton(self)
        self.reset_button.setText("All")
        self.left_side.addWidget(self.reset_button)
        self.left_side.addStretch(1)
        self.install_button = QPushButton(self)
        self.install_button.setText("Install")
        self.left_side.addWidget(self.install_button)

        self.setLayout(self.left_side)

        def musculoskeletal_vis():
            if self.musculoskeletal_label.isChecked():
                self.opensim_label.setChecked(True)
                print("checked")
            else:
                print("unchecked")
        self.musculoskeletal_label.stateChanged.connect(musculoskeletal_vis)

        def gias_core_vis():
            if not self.gias3_label.isChecked():
                self.musculoskeletal_label.setChecked(False)
                self.mapclientpluginutilities_label.setChecked(False)
                self.applications_label.setChecked(False)
                self.visualisation_label.setChecked(False)
                self.examples_label.setChecked(False)
                self.io_label.setChecked(False)
            print("checked")

        self.gias3_label.stateChanged.connect(gias_core_vis)

        def axe_vis():
            print("checked")
        self.mayavi_label.stateChanged.connect(axe_vis)

        def reset_pressed():
            self.musculoskeletal_label.setChecked(True)
            self.gias3_label.setChecked(True)
            self.mapclientpluginutilities_label.setChecked(True)
            self.visualisation_label.setChecked(True)
            self.examples_label.setChecked(True)
            self.examples_label.isChecked()
            self.applications_label.setChecked(True)
            self.mayavi_label.setChecked(True)
            self.io_label.setChecked(True)

            print("Reset")

        self.reset_button.clicked.connect(reset_pressed)
        self.install_button.clicked.connect(self.install_pressed)

    def worker(self):
        count = 0
        self.install_button.setText("Installing ...")
        self.root.info.pbar.setTextVisible(True)
        self.root.info.pbar.setValue(0)
        for i in self.map_list:
            x = self.map_list[i][0]
            print("{0} {1}".format(i, x.isChecked()))
            if x.isChecked():
                count += 1
        idx = 1
        for i in self.map_list:
            x = self.map_list[i][0]
            print("{0} {1}".format(i, x.isChecked()))
            if x.isChecked():
                xi = "<html>"
                xi += "<br>> Installing " + i
                xi += "<br>>> Running " + self.map_list[i][1]
                xi += "</html>"
                self.root.info.textEdit.append(xi)
                self.root.info.textEdit.moveCursor(QTextCursor.End)
                print(self.map_list[i][1])
                os.system(self.map_list[i][1])
                print(int((idx / count) * 100))
                self.root.info.pbar.setValue(int((idx / count) * 100))
                idx += 1
        self.install_button.setText("Close")

    def install_pressed(self):
        if self.install_button.text() == "Close":
            sys.exit(0)

        if self.install_button.text() == "Install":
            w = threading.Thread(target=self.worker)
            w.start()


class MyMainWindow(QMainWindow):

    def __init__(self):
        global information
        super().__init__()
        self.setWindowTitle('Gias3 Python Module Installer')
        self.resize(500, 500)
        self.move(100, 100)
        self.visualwidget = VisualControlWidget(self)
        self.visualwidget.setMaximumWidth(int(500))
        self.info = InfoWidget(self)
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.h_layout = QHBoxLayout()

        self.h_layout.addWidget(self.info)
        self.h_layout.addWidget(self.visualwidget)
        self.central_widget.setLayout(self.h_layout)
        information += "</html>"
        self.show()


if __name__ == '__main__':
    if found:
        try:
            print("Checking for conda ...")
            conda_check = subprocess.check_output('conda',
                                                  stderr=subprocess.STDOUT,
                                                  shell=True)
            conda_boo = True
            print("Checking for conda ... found")
        except subprocess.CalledProcessError:
            print("Checking for conda ... not found")
            information += "<br>> <b><font color=\"red\">No Conda Found. Conda is needed for installing opensim python sdk.</b></font>"

        app = QApplication([])
        windows = MyMainWindow()
        sys.exit(app.exec_())

